package io.neki.storage

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.StatFs
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.ImageView
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.Locale

private val Green = Color(0xFF18785C)
private val Paper = Color(0xFFF5F7F3)
private val Ink = Color(0xFF14241F)
private val Muted = Color(0xFF718079)
private val Line = Color(0xFFE6EBE6)

private data class Photo(
    val uri: Uri,
    val name: String,
    val sizeBytes: Long,
    val dateAdded: Long,
    val favorite: Boolean,
    val screenshot: Boolean
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent { NekiApp() }
    }
}

@Composable
private fun NekiApp() {
    val context = LocalContext.current
    val activity = context as ComponentActivity
    var photos by remember { mutableStateOf<List<Photo>>(emptyList()) }
    var selected by remember { mutableStateOf<Set<Uri>>(emptySet()) }
    var permission by remember { mutableStateOf(hasImagePermission(context)) }
    var scanning by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }
    var preview by remember { mutableStateOf<Photo?>(null) }
    val snackbar = remember { SnackbarHostState() }

    fun scan() {
        if (!hasImagePermission(context)) {
            permission = false
            notice = "צריך לאשר גישה לתמונות כדי לסרוק את המכשיר"
            return
        }
        scanning = true
        Thread {
            val found = queryPhotos(context)
            activity.runOnUiThread {
                photos = found
                selected = found.filter { it.screenshot && !it.favorite }.map { it.uri }.toSet()
                scanning = false
                permission = true
                notice = if (found.isEmpty()) "לא נמצאו תמונות נגישות" else "הסריקה הושלמה: ${found.size} תמונות"
            }
        }.start()
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        permission = hasImagePermission(context)
        if (permission) scan() else notice = "לא ניתנה גישה לתמונות. אפשר לשנות זאת בהגדרות המכשיר."
    }
    val trashLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            selected = emptySet()
            scan()
            notice = "הפריטים שנבחרו הועברו לאשפה"
        } else notice = "המחיקה בוטלה"
    }

    fun requestAccess() {
        val requested = when {
            Build.VERSION.SDK_INT >= 34 -> arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            )
            Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        permissionLauncher.launch(requested)
    }

    fun requestTrash() {
        val uris = photos.filter { it.uri in selected && !it.favorite }.map { it.uri }
        if (uris.isEmpty()) return
        try {
            val request = MediaStore.createTrashRequest(context.contentResolver, uris, true)
            trashLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
        } catch (_: Exception) {
            notice = "Android לא הצליח לפתוח בקשת העברה לאשפה"
        }
    }

    LaunchedEffect(notice) {
        notice?.let { snackbar.showSnackbar(it); notice = null }
    }
    LaunchedEffect(Unit) { if (permission) scan() }

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Paper, surface = Color.White)) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                containerColor = Paper,
                snackbarHost = { SnackbarHost(snackbar) },
                bottomBar = {
                    if (selected.isNotEmpty()) {
                        Surface(color = Ink, shadowElevation = 8.dp) {
                            Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${selected.size} תמונות נבחרו", color = Color.White, fontWeight = FontWeight.SemiBold)
                                Button(onClick = { requestTrash() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE8F4ED), contentColor = Green)) { Text("בדיקה והעברה לאשפה") }
                            }
                        }
                    }
                }
            ) { padding ->
                Column(Modifier.fillMaxSize().padding(padding).statusBarsPadding()) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Surface(color = Green, shape = RoundedCornerShape(13.dp)) { Text("✳", Modifier.padding(horizontal = 11.dp, vertical = 5.dp), color = Color.White, fontSize = 22.sp) }
                            Text("נקי", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
                        }
                        Text("Galaxy S25 FE", color = Muted, fontSize = 13.sp)
                    }
                    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
                        Text("מפנים מקום בראש שקט", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Text("התמונות נשארות במכשיר. את המחיקה מאשרים בנפרד.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))
                        StorageCard()
                        Spacer(Modifier.height(16.dp))
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("התמונות שלך", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
                                Text("${photos.size} תמונות · ${photos.count { it.screenshot }} צילומי מסך", color = Muted, fontSize = 12.sp)
                            }
                            TextButton(onClick = { if (!permission) requestAccess() else scan() }, enabled = !scanning) { Text(if (scanning) "סורקים…" else "סריקה מחדש") }
                        }
                        if (!permission) {
                            Surface(Modifier.fillMaxWidth().padding(top = 12.dp), color = Color.White, shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Line)) {
                                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("כדי להציג תמונות אמיתיות, צריך לאשר גישה למדיה", color = Ink, textAlign = TextAlign.Center)
                                    Button(onClick = { requestAccess() }, Modifier.padding(top = 12.dp)) { Text("אישור גישה לתמונות") }
                                }
                            }
                        } else if (photos.isEmpty() && !scanning) {
                            Surface(Modifier.fillMaxWidth().padding(top = 12.dp), color = Color.White, shape = RoundedCornerShape(16.dp)) {
                                Text(if (scanning) "סורקים תמונות…" else "לא נמצאו תמונות נגישות. בדקו את הרשאות התמונות." , Modifier.padding(24.dp), color = Muted, textAlign = TextAlign.Center)
                            }
                        } else {
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(3),
                                modifier = Modifier.weight(1f).padding(top = 10.dp),
                                contentPadding = PaddingValues(bottom = 20.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(photos, key = { it.uri.toString() }) { photo ->
                                    PhotoTile(photo, selected.contains(photo.uri), onToggle = {
                                        if (photo.favorite) notice = "תמונה מועדפת מוגנת מכל מחיקה"
                                        else selected = if (photo.uri in selected) selected - photo.uri else selected + photo.uri
                                    }, onPreview = { preview = photo })
                                }
                            }
                        }
                    }
                }
            }
            preview?.let { photo ->
                Dialog(onDismissRequest = { preview = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
                    Surface(Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(20.dp), color = Color.White) {
                        Column(Modifier.padding(16.dp)) {
                            PhotoImage(photo.uri, Modifier.fillMaxWidth().height(370.dp).clip(RoundedCornerShape(14.dp)), ContentScale.Fit)
                            Text(photo.name, Modifier.padding(top = 12.dp), color = Ink, fontWeight = FontWeight.SemiBold)
                            Text(if (photo.favorite) "♡ מועדפת — מוגנת" else if (photo.screenshot) "צילום מסך · ${readableSize(photo.sizeBytes)}" else readableSize(photo.sizeBytes), color = Muted, fontSize = 13.sp)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                TextButton(onClick = { preview = null }) { Text("סגירה") }
                                if (!photo.favorite) TextButton(onClick = { selected = if (photo.uri in selected) selected - photo.uri else selected + photo.uri }) { Text(if (photo.uri in selected) "הסר מהבחירה" else "בחירה לפינוי") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StorageCard() {
    val context = LocalContext.current
    val (used, total) = remember {
        try {
            val stat = StatFs(android.os.Environment.getExternalStorageDirectory().path)
            val totalBytes = stat.totalBytes
            val freeBytes = stat.availableBytes
            (totalBytes - freeBytes) to totalBytes
        } catch (_: Exception) { 0L to 0L }
    }
    val fraction = if (total > 0) (used.toFloat() / total).coerceIn(0f, 1f) else 0f
    Surface(Modifier.fillMaxWidth(), color = Color.White, shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Line)) {
        Column(Modifier.padding(17.dp)) {
            Text("האחסון במכשיר", color = Muted, fontSize = 12.sp)
            Text(if (total > 0) "${readableSize(used)} מתוך ${readableSize(total)}" else "פרטי האחסון יוצגו לאחר הסריקה", color = Ink, fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.padding(top = 3.dp))
            Spacer(Modifier.height(11.dp))
            LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(8.dp)), color = Green, trackColor = Line)
            Text("${(fraction * 100).toInt()}% בשימוש", Modifier.fillMaxWidth().padding(top = 6.dp), color = Muted, fontSize = 11.sp, textAlign = TextAlign.End)
        }
    }
}

@Composable
private fun PhotoTile(photo: Photo, checked: Boolean, onToggle: () -> Unit, onPreview: () -> Unit) {
    Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(12.dp)).background(Color(0xFFE8ECE8))) {
        PhotoImage(photo.uri, Modifier.fillMaxSize().clickable(onClick = onPreview), ContentScale.Crop)
        if (photo.favorite) {
            Surface(Modifier.align(Alignment.TopEnd).padding(5.dp), color = Color.White.copy(alpha = .94f), shape = RoundedCornerShape(20.dp)) { Text("♡ מוגנת", Modifier.padding(horizontal = 7.dp, vertical = 3.dp), color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
        } else if (photo.screenshot) {
            Surface(Modifier.align(Alignment.TopStart).padding(5.dp), color = Color.White.copy(alpha = .94f), shape = RoundedCornerShape(20.dp)) { Text("צילום מסך", Modifier.padding(horizontal = 7.dp, vertical = 3.dp), color = Ink, fontSize = 10.sp) }
        }
        if (!photo.favorite) {
            Checkbox(checked = checked, onCheckedChange = { onToggle() }, modifier = Modifier.align(Alignment.BottomEnd).padding(2.dp).size(38.dp))
        }
    }
}

@Composable
private fun PhotoImage(uri: Uri, modifier: Modifier = Modifier, scale: ContentScale) {
    val context = LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, uri) {
        value = withContext(Dispatchers.IO) {
            try {
                if (Build.VERSION.SDK_INT >= 29) context.contentResolver.loadThumbnail(uri, Size(640, 640), null) else null
            } catch (_: IOException) { null }
            catch (_: SecurityException) { null }
        }
    }
    if (bitmap != null) {
        AndroidView(factory = { ImageView(it).apply { scaleType = if (scale == ContentScale.Crop) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER } }, update = { it.setImageBitmap(bitmap) }, modifier = modifier)
    } else {
        Box(modifier.background(Color(0xFFE3E9E4)), contentAlignment = Alignment.Center) { Text("▧", color = Muted, fontSize = 25.sp) }
    }
}

private fun hasImagePermission(context: android.content.Context): Boolean = when {
    Build.VERSION.SDK_INT >= 34 -> ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED
    Build.VERSION.SDK_INT >= 33 -> ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
    else -> ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
}

private fun queryPhotos(context: android.content.Context): List<Photo> {
    if (!hasImagePermission(context)) return emptyList()
    val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    val projection = mutableListOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
    if (Build.VERSION.SDK_INT >= 30) projection.add(MediaStore.Images.Media.IS_FAVORITE)
    val result = mutableListOf<Photo>()
    val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"
    context.contentResolver.query(collection, projection.toTypedArray(), null, null, sortOrder)?.use { cursor ->
        val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
        val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
        val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
        val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
        val bucketCol = cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
        val favoriteCol = if (Build.VERSION.SDK_INT >= 30) cursor.getColumnIndex(MediaStore.Images.Media.IS_FAVORITE) else -1
        while (cursor.moveToNext() && result.size < 3000) {
            val id = cursor.getLong(idCol)
            val uri = ContentUris.withAppendedId(collection, id)
            val name = cursor.getString(nameCol) ?: "תמונה"
            val bucket = if (bucketCol >= 0) cursor.getString(bucketCol).orEmpty() else ""
            val isFavorite = favoriteCol >= 0 && cursor.getInt(favoriteCol) == 1
            val isScreenshot = bucket.contains("screenshot", true) || name.contains("screenshot", true) || name.contains("צילום מסך")
            result += Photo(uri, name, cursor.getLong(sizeCol), cursor.getLong(dateCol), isFavorite, isScreenshot)
        }
    }
    return result
}

private fun readableSize(bytes: Long): String {
    if (bytes <= 0) return "0 בייט"
    val gb = bytes / (1024.0 * 1024.0 * 1024.0)
    return if (gb >= 1) String.format(Locale.getDefault(), "%.1f ג״ב", gb) else String.format(Locale.getDefault(), "%.0f מ״ב", bytes / (1024.0 * 1024.0))
}
